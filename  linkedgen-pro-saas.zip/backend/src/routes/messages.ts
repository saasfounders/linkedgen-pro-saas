import { Router, Request, Response } from 'express';
import { authenticateToken } from '../middleware/auth';
import { query } from '../config/database';
import { generateAIMessage } from '../services/openaiService';

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
  };
}

const router = Router();

// Generate AI message for a lead
router.post('/generate', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { lead_id, type = 'initial' } = req.body;

    if (!lead_id) {
      return res.status(400).json({ error: 'lead_id is required' });
    }

    // Get lead information
    const leadResult = await query(
      'SELECT name, company, industry FROM leads WHERE id = $1 AND user_id = $2',
      [lead_id, userId]
    );

    if (leadResult.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    const lead = leadResult.rows[0];

    // Generate AI message
    const message = await generateAIMessage({
      leadName: lead.name,
      company: lead.company,
      industry: lead.industry,
      messageType: type
    });

    // Save message to database
    const messageResult = await query(
      'INSERT INTO messages (lead_id, user_id, content, message_type) VALUES ($1, $2, $3, $4) RETURNING id, content, message_type, created_at',
      [lead_id, userId, message, type]
    );

    res.json({
      message,
      message_id: messageResult.rows[0].id,
      type: messageResult.rows[0].message_type
    });
  } catch (error) {
    console.error('Generate message error:', error);
    res.status(500).json({ error: 'Failed to generate message' });
  }
});

// Get all messages for a lead
router.get('/lead/:leadId', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const leadId = req.params.leadId;

    const result = await query(
      'SELECT id, content, message_type, created_at FROM messages WHERE lead_id = $1 AND user_id = $2 ORDER BY created_at DESC',
      [leadId, userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// Get all messages for user
router.get('/', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;

    const result = await query(
      `SELECT m.id, m.content, m.message_type, m.created_at, 
              l.name as lead_name, l.company as lead_company 
       FROM messages m 
       JOIN leads l ON m.lead_id = l.id 
       WHERE m.user_id = $1 
       ORDER BY m.created_at DESC`,
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get all messages error:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

export default router; 