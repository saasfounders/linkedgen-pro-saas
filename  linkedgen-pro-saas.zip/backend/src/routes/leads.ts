import { Router, Request, Response } from 'express';
import { authenticateToken } from '../middleware/auth';
import { query } from '../config/database';
import { generateLeadsFromApollo } from '../services/apolloService';
import { sendTelegramNotification } from '../services/telegramService';

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
  };
}

const router = Router();

// Get all leads for user
router.get('/', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const result = await query(
      'SELECT id, name, company, industry, score, created_at FROM leads WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get leads error:', error);
    res.status(500).json({ error: 'Failed to fetch leads' });
  }
});

// Generate leads from Apollo API
router.post('/generate', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    
    // Generate leads from Apollo API
    const generatedLeads = await generateLeadsFromApollo();
    
    // Save leads to database
    const savedLeads = [];
    for (const lead of generatedLeads) {
      const result = await query(
        'INSERT INTO leads (user_id, name, company, industry, score) VALUES ($1, $2, $3, $4, $5) RETURNING id, name, company, industry, score',
        [userId, lead.name, lead.company, lead.industry, lead.score]
      );
      savedLeads.push(result.rows[0]);
    }

    // Send Telegram notification
    await sendTelegramNotification(
      `🎯 Generated ${savedLeads.length} new leads for user ${req.user!.email}`
    );

    res.json({
      generated: savedLeads.length,
      source: 'apollo',
      leads: savedLeads
    });
  } catch (error) {
    console.error('Generate leads error:', error);
    res.status(500).json({ error: 'Failed to generate leads' });
  }
});

// Get lead by ID
router.get('/:id', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const leadId = req.params.id;

    const result = await query(
      'SELECT id, name, company, industry, score, created_at FROM leads WHERE id = $1 AND user_id = $2',
      [leadId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get lead error:', error);
    res.status(500).json({ error: 'Failed to fetch lead' });
  }
});

// Delete lead
router.delete('/:id', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const leadId = req.params.id;

    const result = await query(
      'DELETE FROM leads WHERE id = $1 AND user_id = $2 RETURNING id',
      [leadId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.json({ message: 'Lead deleted successfully' });
  } catch (error) {
    console.error('Delete lead error:', error);
    res.status(500).json({ error: 'Failed to delete lead' });
  }
});

export default router; 