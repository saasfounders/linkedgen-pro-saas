'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import toast from 'react-hot-toast'
import { 
  Users, 
  MessageSquare, 
  Plus, 
  Search, 
  Filter, 
  MoreVertical,
  Sparkles,
  LogOut,
  User,
  Building,
  TrendingUp
} from 'lucide-react'

interface Lead {
  id: string
  name: string
  company: string
  industry: string
  score: number
  created_at: string
}

interface Message {
  id: string
  content: string
  message_type: string
  created_at: string
  lead_name: string
  lead_company: string
}

export default function Dashboard() {
  const [leads, setLeads] = useState<Lead[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isGeneratingLeads, setIsGeneratingLeads] = useState(false)
  const [isGeneratingMessage, setIsGeneratingMessage] = useState(false)
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')
    
    if (!token) {
      router.push('/')
      return
    }

    if (userData) {
      setUser(JSON.parse(userData))
    }

    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token')
      const headers = { Authorization: `Bearer ${token}` }

      const [leadsRes, messagesRes] = await Promise.all([
        axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/leads`, { headers }),
        axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/messages`, { headers })
      ])

      setLeads(leadsRes.data)
      setMessages(messagesRes.data)
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Failed to load data')
    } finally {
      setIsLoading(false)
    }
  }

  const generateLeads = async () => {
    setIsGeneratingLeads(true)
    try {
      const token = localStorage.getItem('token')
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/api/leads/generate`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      )
      
      toast.success(`Generated ${response.data.generated} new leads!`)
      fetchData()
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to generate leads')
    } finally {
      setIsGeneratingLeads(false)
    }
  }

  const generateMessage = async (leadId: string) => {
    setIsGeneratingMessage(true)
    try {
      const token = localStorage.getItem('token')
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/api/messages/generate`,
        { lead_id: leadId, type: 'initial' },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      
      toast.success('AI message generated!')
      fetchData()
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to generate message')
    } finally {
      setIsGeneratingMessage(false)
    }
  }

  const logout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Sparkles className="h-8 w-8 text-primary-600 mr-2" />
              <h1 className="text-xl font-semibold text-gray-900">LinkedGen Pro</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-sm text-gray-700">
                <User className="h-4 w-4 mr-1" />
                {user?.email}
              </div>
              <button
                onClick={logout}
                className="flex items-center text-sm text-gray-600 hover:text-gray-900"
              >
                <LogOut className="h-4 w-4 mr-1" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="card">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-primary-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-gray-600">Total Leads</p>
                <p className="text-2xl font-bold text-gray-900">{leads.length}</p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <MessageSquare className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-gray-600">Messages Sent</p>
                <p className="text-2xl font-bold text-gray-900">{messages.length}</p>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Lead Score</p>
                <p className="text-2xl font-bold text-gray-900">
                  {leads.length > 0 
                    ? Math.round(leads.reduce((sum, lead) => sum + lead.score, 0) / leads.length)
                    : 0
                  }
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Leads</h2>
          <button
            onClick={generateLeads}
            disabled={isGeneratingLeads}
            className="btn-primary flex items-center"
          >
            {isGeneratingLeads ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            ) : (
              <Plus className="h-4 w-4 mr-2" />
            )}
            Generate Leads
          </button>
        </div>

        {/* Leads Table */}
        <div className="card">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Company
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Industry
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {leads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{lead.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Building className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-900">{lead.company}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-900">{lead.industry}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        lead.score >= 90 ? 'bg-green-100 text-green-800' :
                        lead.score >= 80 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {lead.score}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => generateMessage(lead.id)}
                        disabled={isGeneratingMessage}
                        className="text-primary-600 hover:text-primary-900 flex items-center"
                      >
                        <Sparkles className="h-4 w-4 mr-1" />
                        Generate Message
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Messages */}
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Messages</h2>
          <div className="space-y-4">
            {messages.slice(0, 5).map((message) => (
              <div key={message.id} className="card">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium text-gray-900">{message.lead_name}</h3>
                    <p className="text-sm text-gray-600">{message.lead_company}</p>
                  </div>
                  <span className="text-xs text-gray-500">
                    {new Date(message.created_at).toLocaleDateString()}
                  </span>
                </div>
                <p className="text-gray-700 text-sm">{message.content}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
} 