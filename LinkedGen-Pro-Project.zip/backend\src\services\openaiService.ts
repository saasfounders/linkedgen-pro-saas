import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface MessageGenerationParams {
  leadName: string;
  company: string;
  industry?: string;
  messageType: string;
}

export const generateAIMessage = async (params: MessageGenerationParams): Promise<string> => {
  try {
    const { leadName, company, industry, messageType } = params;

    const prompt = `You are a professional LinkedIn outreach specialist. Generate a personalized LinkedIn message for a lead.

Lead Information:
- Name: ${leadName}
- Company: ${company}
- Industry: ${industry || 'Not specified'}
- Message Type: ${messageType}

Requirements:
- Keep it under 150 words
- Be professional but friendly
- Personalize based on company and industry
- Include a clear call-to-action
- Avoid being too salesy
- Make it conversational

Generate a compelling LinkedIn message:`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert LinkedIn outreach specialist who creates personalized, professional messages that drive engagement."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 300,
      temperature: 0.7,
    });

    const message = completion.choices[0]?.message?.content?.trim();
    
    if (!message) {
      throw new Error('Failed to generate message');
    }

    return message;
  } catch (error) {
    console.error('OpenAI API error:', error);
    
    // Fallback message if OpenAI fails
    return `Hi ${params.leadName},

I noticed ${params.company} is doing some interesting work in ${params.industry || 'your industry'}. I'd love to connect and learn more about what you're working on.

Would you be open to a quick chat?

Best regards`;
  }
}; 