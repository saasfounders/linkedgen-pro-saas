import TelegramBot from 'node-telegram-bot-api';

let bot: TelegramBot | null = null;

export const initializeTelegramBot = () => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  
  if (!token) {
    console.warn('Telegram bot token not configured');
    return;
  }

  try {
    bot = new TelegramBot(token, { polling: false });
    console.log('✅ Telegram bot initialized');
  } catch (error) {
    console.error('❌ Failed to initialize Telegram bot:', error);
  }
};

export const sendTelegramNotification = async (message: string): Promise<void> => {
  try {
    const chatId = process.env.TELEGRAM_CHAT_ID;
    
    if (!bot || !chatId) {
      console.warn('Telegram bot or chat ID not configured');
      return;
    }

    await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
    console.log('✅ Telegram notification sent');
  } catch (error) {
    console.error('❌ Failed to send Telegram notification:', error);
  }
};

export const sendLeadGenerationNotification = async (count: number, userEmail: string): Promise<void> => {
  const message = `🎯 <b>New Leads Generated</b>

📊 <b>Count:</b> ${count} leads
👤 <b>User:</b> ${userEmail}
⏰ <b>Time:</b> ${new Date().toLocaleString()}

Generated via Apollo API integration.`;

  await sendTelegramNotification(message);
};

export const sendMessageGenerationNotification = async (leadName: string, company: string, userEmail: string): Promise<void> => {
  const message = `💬 <b>AI Message Generated</b>

👤 <b>Lead:</b> ${leadName}
🏢 <b>Company:</b> ${company}
👨‍💼 <b>User:</b> ${userEmail}
⏰ <b>Time:</b> ${new Date().toLocaleString()}

Generated using OpenAI GPT-4o.`;

  await sendTelegramNotification(message);
};

// Initialize bot when module is loaded
initializeTelegramBot(); 