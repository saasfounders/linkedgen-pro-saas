import axios from 'axios';

interface ApolloLead {
  name: string;
  company: string;
  industry: string;
  score: number;
}

export const generateLeadsFromApollo = async (): Promise<ApolloLead[]> => {
  try {
    const apiKey = process.env.APOLLO_API_KEY;
    
    if (!apiKey) {
      console.warn('Apollo API key not configured, using mock data');
      return generateMockLeads();
    }

    // Apollo API endpoint for people search
    const response = await axios.get('https://api.apollo.io/v1/people/search', {
      headers: {
        'X-Api-Key': apiKey,
        'Content-Type': 'application/json'
      },
      params: {
        api_key: apiKey,
        page: 1,
        per_page: 20,
        q_organization_domains: 'linkedin.com',
        q_titles: ['CEO', 'CTO', 'VP', 'Director', 'Manager'],
        q_organization_industries: ['Technology', 'Software', 'SaaS'],
        q_organization_locations: ['United States', 'Canada', 'United Kingdom']
      }
    });

    if (response.data && response.data.people) {
      return response.data.people.map((person: any) => ({
        name: `${person.first_name} ${person.last_name}`,
        company: person.organization?.name || 'Unknown Company',
        industry: person.organization?.industry || 'Technology',
        score: Math.floor(Math.random() * 30) + 70 // Random score between 70-100
      }));
    }

    return generateMockLeads();
  } catch (error) {
    console.error('Apollo API error:', error);
    console.log('Falling back to mock data');
    return generateMockLeads();
  }
};

const generateMockLeads = (): ApolloLead[] => {
  const mockCompanies = [
    'TechCorp Inc', 'InnovateSoft', 'DataFlow Systems', 'CloudScale', 'NextGen Solutions',
    'Digital Dynamics', 'SmartTech', 'FutureWorks', 'Elite Software', 'Peak Performance'
  ];

  const mockNames = [
    'John Smith', 'Sarah Johnson', 'Michael Brown', 'Emily Davis', 'David Wilson',
    'Lisa Anderson', 'Robert Taylor', 'Jennifer Martinez', 'Christopher Garcia', 'Amanda Rodriguez'
  ];

  const mockIndustries = [
    'Technology', 'Software Development', 'SaaS', 'FinTech', 'HealthTech',
    'E-commerce', 'Marketing', 'Consulting', 'Manufacturing', 'Education'
  ];

  const leads: ApolloLead[] = [];
  
  for (let i = 0; i < 20; i++) {
    leads.push({
      name: mockNames[Math.floor(Math.random() * mockNames.length)],
      company: mockCompanies[Math.floor(Math.random() * mockCompanies.length)],
      industry: mockIndustries[Math.floor(Math.random() * mockIndustries.length)],
      score: Math.floor(Math.random() * 30) + 70 // Random score between 70-100
    });
  }

  return leads;
}; 