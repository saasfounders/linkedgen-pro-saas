import { Router, Request, Response } from 'express';
import { authenticateToken } from '../middleware/auth';
import { query } from '../config/database';
import Joi from 'joi';

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
  };
}

const router = Router();

// Validation schema
const icpSchema = Joi.object({
  name: Joi.string().required(),
  industries: Joi.array().items(Joi.string()),
  geography: Joi.array().items(Joi.string())
});

// Get all ICP profiles for user
router.get('/', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const result = await query(
      'SELECT id, name, industries, geography, created_at FROM icp_profiles WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get ICP profiles error:', error);
    res.status(500).json({ error: 'Failed to fetch ICP profiles' });
  }
});

// Create new ICP profile
router.post('/', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { error, value } = icpSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { name, industries, geography } = value;

    const result = await query(
      'INSERT INTO icp_profiles (user_id, name, industries, geography) VALUES ($1, $2, $3, $4) RETURNING id, name, industries, geography, created_at',
      [userId, name, industries, geography]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create ICP profile error:', error);
    res.status(500).json({ error: 'Failed to create ICP profile' });
  }
});

// Get ICP profile by ID
router.get('/:id', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const icpId = req.params.id;

    const result = await query(
      'SELECT id, name, industries, geography, created_at FROM icp_profiles WHERE id = $1 AND user_id = $2',
      [icpId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ICP profile not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get ICP profile error:', error);
    res.status(500).json({ error: 'Failed to fetch ICP profile' });
  }
});

// Update ICP profile
router.put('/:id', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const icpId = req.params.id;
    const { error, value } = icpSchema.validate(req.body);
    
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { name, industries, geography } = value;

    const result = await query(
      'UPDATE icp_profiles SET name = $1, industries = $2, geography = $3 WHERE id = $4 AND user_id = $5 RETURNING id, name, industries, geography, created_at',
      [name, industries, geography, icpId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ICP profile not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update ICP profile error:', error);
    res.status(500).json({ error: 'Failed to update ICP profile' });
  }
});

// Delete ICP profile
router.delete('/:id', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const icpId = req.params.id;

    const result = await query(
      'DELETE FROM icp_profiles WHERE id = $1 AND user_id = $2 RETURNING id',
      [icpId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'ICP profile not found' });
    }

    res.json({ message: 'ICP profile deleted successfully' });
  } catch (error) {
    console.error('Delete ICP profile error:', error);
    res.status(500).json({ error: 'Failed to delete ICP profile' });
  }
});

export default router; 